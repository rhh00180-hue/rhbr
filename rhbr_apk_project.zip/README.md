# RH.BR APK Project

## Rodar no Expo
1. Instale dependências: `npm install` ou `yarn install`
2. Inicie o app: `npx expo start`
3. Para gerar APK: `eas build -p android --profile production`

## Login
- Usa Supabase Auth (email/senha).
- Após login, mostra link se disponível ou imagem com mensagem.
