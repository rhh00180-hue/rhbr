import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qnhrduvrwbgxxaidmnpz.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFuaHJkdXZyd2JneHhhaWRtbnB6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgyMzMyNDgsImV4cCI6MjA3MzgwOTI0OH0.ZpHQ4Cubof67gkKG9evHpIWHhlag4LSvytyLC99AyPc';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
