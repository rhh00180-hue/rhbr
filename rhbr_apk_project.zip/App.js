import React, { useState } from 'react';
import { View, Text, TextInput, Button, Image, StyleSheet } from 'react-native';
import { supabase } from './supabase';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [link, setLink] = useState(null);

  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (!error) {
      setLoggedIn(true);
      // Buscar link do supabase futuramente
      setLink(null);
    } else {
      alert(error.message);
    }
  };

  if (!loggedIn) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Login RH.BR</Text>
        <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={styles.input}/>
        <TextInput placeholder="Senha" secureTextEntry value={password} onChangeText={setPassword} style={styles.input}/>
        <Button title="Entrar" onPress={handleLogin} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {link ? (
        <View>
          <Text style={styles.title}>Clique abaixo para acessar:</Text>
          <Text style={styles.link}>{link}</Text>
        </View>
      ) : (
        <View style={styles.centered}>
          <Image source={require('./assets/waiting.png')} style={{ width: 250, height: 250, marginBottom: 20 }} />
          <Text style={styles.waitingText}>Estamos preparando as melhores vagas para você</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#0A74DA'
  },
  title: { fontSize: 24, color: 'white', marginBottom: 20 },
  input: { backgroundColor: 'white', padding: 10, width: '100%', marginBottom: 10, borderRadius: 5 },
  link: { color: 'yellow', fontSize: 18, textAlign: 'center', marginTop: 20 },
  centered: { justifyContent: 'center', alignItems: 'center' },
  waitingText: { color: 'white', fontSize: 16, textAlign: 'center' }
});
